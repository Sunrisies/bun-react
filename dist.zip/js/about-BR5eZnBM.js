import{j as n}from"./index-C6l0Aoxs.js";const o=function(){return n.jsx("main",{children:"wq"})};export{o as component};
