import{a as e,b as t,d as i,e as r,f as n,g as o,h as l,i as a,k as s,l as d,s as c,m as f,n as u,o as p,p as g,q as h,v,w as x,x as m,D as b}from"./index-C6l0Aoxs.js";import{c as $}from"./clsx-BeLtu-UY.js";const y=e(void 0),k=e(void 0),C="undefined"==typeof window;function S(e){return e.isFetching&&"success"===e.status?"beforeLoad"===e.isFetching?"purple":"blue":{pending:"yellow",success:"green",error:"red",notFound:"purple",redirected:"gray"}[e.status]}let w={data:""},F=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,z=/\/\*[^]*?\*\/|  +/g,U=/\n+/g,M=(e,t)=>{let i="",r="",n="";for(let o in e){let l=e[o];"@"==o[0]?"i"==o[1]?i=o+" "+l+";":r+="f"==o[1]?M(l,o):o+"{"+M(l,"k"==o[1]?"":t)+"}":"object"==typeof l?r+=M(l,t?t.replace(/([^,])+/g,(e=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,(t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)))):o):null!=l&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),n+=M.p?M.p(o,l):o+":"+l+";")}return i+(t&&n?t+"{"+n+"}":n)+r},O={},B=e=>{if("object"==typeof e){let t="";for(let i in e)t+=i+B(e[i]);return t}return e};function E(e){let t=this||{},i=e.call?e(t.p):e;return((e,t,i,r,n)=>{let o=B(e),l=O[o]||(O[o]=(e=>{let t=0,i=11;for(;t<e.length;)i=101*i+e.charCodeAt(t++)>>>0;return"go"+i})(o));if(!O[l]){let t=o!==e?e:(e=>{let t,i,r=[{}];for(;t=F.exec(e.replace(z,""));)t[4]?r.shift():t[3]?(i=t[3].replace(U," ").trim(),r.unshift(r[0][i]=r[0][i]||{})):r[0][t[1]]=t[2].replace(U," ").trim();return r[0]})(e);O[l]=M(n?{["@keyframes "+l]:t}:t,i?"":"."+l)}let a=i&&O.g?O.g:null;return i&&(O.g=O[l]),s=O[l],d=t,c=r,(f=a)?d.data=d.data.replace(f,s):-1===d.data.indexOf(s)&&(d.data=c?s+d.data:d.data+s),l;var s,d,c,f})(i.unshift?i.raw?((e,t,i)=>e.reduce(((e,r,n)=>{let o=t[n];if(o&&o.call){let e=o(i),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;o=t?"."+t:e&&"object"==typeof e?e.props?"":M(e,""):!1===e?"":e}return e+r+(null==o?"":o)}),""))(i,[].slice.call(arguments,1),t.p):i.reduce(((e,i)=>Object.assign(e,i&&i.call?i(t.p):i)),{}):i,(r=t.target,"object"==typeof window?((r?r.querySelector("#_goober"):window._goober)||Object.assign((r||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:r||w),t.g,t.o,t.k);var r}E.bind({g:1}),E.bind({k:1});const D={colors:{inherit:"inherit",current:"currentColor",transparent:"transparent",black:"#000000",white:"#ffffff",neutral:{50:"#f9fafb",100:"#f2f4f7",200:"#eaecf0",300:"#d0d5dd",400:"#98a2b3",500:"#667085",600:"#475467",700:"#344054",800:"#1d2939",900:"#101828"},darkGray:{50:"#525c7a",100:"#49536e",200:"#414962",300:"#394056",400:"#313749",500:"#292e3d",600:"#212530",700:"#191c24",800:"#111318",900:"#0b0d10"},gray:{50:"#f9fafb",100:"#f2f4f7",200:"#eaecf0",300:"#d0d5dd",400:"#98a2b3",500:"#667085",600:"#475467",700:"#344054",800:"#1d2939",900:"#101828"},blue:{25:"#F5FAFF",50:"#EFF8FF",100:"#D1E9FF",200:"#B2DDFF",300:"#84CAFF",400:"#53B1FD",500:"#2E90FA",600:"#1570EF",700:"#175CD3",800:"#1849A9",900:"#194185"},green:{25:"#F6FEF9",50:"#ECFDF3",100:"#D1FADF",200:"#A6F4C5",300:"#6CE9A6",400:"#32D583",500:"#12B76A",600:"#039855",700:"#027A48",800:"#05603A",900:"#054F31"},red:{50:"#fef2f2",100:"#fee2e2",200:"#fecaca",300:"#fca5a5",400:"#f87171",500:"#ef4444",600:"#dc2626",700:"#b91c1c",800:"#991b1b",900:"#7f1d1d",950:"#450a0a"},yellow:{25:"#FFFCF5",50:"#FFFAEB",100:"#FEF0C7",200:"#FEDF89",300:"#FEC84B",400:"#FDB022",500:"#F79009",600:"#DC6803",700:"#B54708",800:"#93370D",900:"#7A2E0E"},purple:{25:"#FAFAFF",50:"#F4F3FF",100:"#EBE9FE",200:"#D9D6FE",300:"#BDB4FE",400:"#9B8AFB",500:"#7A5AF8",600:"#6938EF",700:"#5925DC",800:"#4A1FB8",900:"#3E1C96"},teal:{25:"#F6FEFC",50:"#F0FDF9",100:"#CCFBEF",200:"#99F6E0",300:"#5FE9D0",400:"#2ED3B7",500:"#15B79E",600:"#0E9384",700:"#107569",800:"#125D56",900:"#134E48"},pink:{25:"#fdf2f8",50:"#fce7f3",100:"#fbcfe8",200:"#f9a8d4",300:"#f472b6",400:"#ec4899",500:"#db2777",600:"#be185d",700:"#9d174d",800:"#831843",900:"#500724"},cyan:{25:"#ecfeff",50:"#cffafe",100:"#a5f3fc",200:"#67e8f9",300:"#22d3ee",400:"#06b6d4",500:"#0891b2",600:"#0e7490",700:"#155e75",800:"#164e63",900:"#083344"}},alpha:{90:"e5",70:"b3",20:"33"},font:{size:{"2xs":"calc(var(--tsrd-font-size) * 0.625)",xs:"calc(var(--tsrd-font-size) * 0.75)",sm:"calc(var(--tsrd-font-size) * 0.875)",md:"var(--tsrd-font-size)"},lineHeight:{xs:"calc(var(--tsrd-font-size) * 1)",sm:"calc(var(--tsrd-font-size) * 1.25)"},weight:{normal:"400",medium:"500",semibold:"600",bold:"700"},fontFamily:{sans:"ui-sans-serif, Inter, system-ui, sans-serif, sans-serif",mono:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace"}},border:{radius:{xs:"calc(var(--tsrd-font-size) * 0.125)",sm:"calc(var(--tsrd-font-size) * 0.25)",md:"calc(var(--tsrd-font-size) * 0.375)",full:"9999px"}},size:{0:"0px",.5:"calc(var(--tsrd-font-size) * 0.125)",1:"calc(var(--tsrd-font-size) * 0.25)",1.5:"calc(var(--tsrd-font-size) * 0.375)",2:"calc(var(--tsrd-font-size) * 0.5)",2.5:"calc(var(--tsrd-font-size) * 0.625)",3:"calc(var(--tsrd-font-size) * 0.75)",3.5:"calc(var(--tsrd-font-size) * 0.875)",4:"calc(var(--tsrd-font-size) * 1)",5:"calc(var(--tsrd-font-size) * 1.25)",8:"calc(var(--tsrd-font-size) * 2)"}};function G(){const e=t(y),[r]=i((e=>{const{colors:t,font:i,size:r,alpha:n,border:o}=D,{fontFamily:l,lineHeight:a,size:s}=i,d=e?E.bind({target:e}):E;return{devtoolsPanelContainer:d`
      direction: ltr;
      position: fixed;
      bottom: 0;
      right: 0;
      z-index: 99999;
      width: 100%;
      max-height: 90%;
      border-top: 1px solid ${t.gray[700]};
      transform-origin: top;
    `,devtoolsPanelContainerVisibility:e=>d`
        visibility: ${e?"visible":"hidden"};
      `,devtoolsPanelContainerResizing:e=>e()?d`
          transition: none;
        `:d`
        transition: all 0.4s ease;
      `,devtoolsPanelContainerAnimation:(e,t)=>e?d`
          pointer-events: auto;
          transform: translateY(0);
        `:d`
        pointer-events: none;
        transform: translateY(${t}px);
      `,logo:d`
      cursor: pointer;
      display: flex;
      flex-direction: column;
      background-color: transparent;
      border: none;
      font-family: ${l.sans};
      gap: ${D.size[.5]};
      padding: 0px;
      &:hover {
        opacity: 0.7;
      }
      &:focus-visible {
        outline-offset: 4px;
        border-radius: ${o.radius.xs};
        outline: 2px solid ${t.blue[800]};
      }
    `,tanstackLogo:d`
      font-size: ${i.size.md};
      font-weight: ${i.weight.bold};
      line-height: ${i.lineHeight.xs};
      white-space: nowrap;
      color: ${t.gray[300]};
    `,routerLogo:d`
      font-weight: ${i.weight.semibold};
      font-size: ${i.size.xs};
      background: linear-gradient(to right, #84cc16, #10b981);
      background-clip: text;
      -webkit-background-clip: text;
      line-height: 1;
      -webkit-text-fill-color: transparent;
      white-space: nowrap;
    `,devtoolsPanel:d`
      display: flex;
      font-size: ${s.sm};
      font-family: ${l.sans};
      background-color: ${t.darkGray[700]};
      color: ${t.gray[300]};

      @media (max-width: 700px) {
        flex-direction: column;
      }
      @media (max-width: 600px) {
        font-size: ${s.xs};
      }
    `,dragHandle:d`
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 4px;
      cursor: row-resize;
      z-index: 100000;
      &:hover {
        background-color: ${t.purple[400]}${n[90]};
      }
    `,firstContainer:d`
      flex: 1 1 500px;
      min-height: 40%;
      max-height: 100%;
      overflow: auto;
      border-right: 1px solid ${t.gray[700]};
      display: flex;
      flex-direction: column;
    `,routerExplorerContainer:d`
      overflow-y: auto;
      flex: 1;
    `,routerExplorer:d`
      padding: ${D.size[2]};
    `,row:d`
      display: flex;
      align-items: center;
      padding: ${D.size[2]} ${D.size[2.5]};
      gap: ${D.size[2.5]};
      border-bottom: ${t.darkGray[500]} 1px solid;
      align-items: center;
    `,detailsHeader:d`
      font-family: ui-sans-serif, Inter, system-ui, sans-serif, sans-serif;
      position: sticky;
      top: 0;
      z-index: 2;
      background-color: ${t.darkGray[600]};
      padding: 0px ${D.size[2]};
      font-weight: ${i.weight.medium};
      font-size: ${i.size.xs};
      min-height: ${D.size[8]};
      line-height: ${i.lineHeight.xs};
      text-align: left;
      display: flex;
      align-items: center;
    `,maskedBadge:d`
      background: ${t.yellow[900]}${n[70]};
      color: ${t.yellow[300]};
      display: inline-block;
      padding: ${D.size[0]} ${D.size[2.5]};
      border-radius: ${o.radius.full};
      font-size: ${i.size.xs};
      font-weight: ${i.weight.normal};
      border: 1px solid ${t.yellow[300]};
    `,maskedLocation:d`
      color: ${t.yellow[300]};
    `,detailsContent:d`
      padding: ${D.size[1.5]} ${D.size[2]};
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: ${i.size.xs};
    `,routeMatchesToggle:d`
      display: flex;
      align-items: center;
      border: 1px solid ${t.gray[500]};
      border-radius: ${o.radius.sm};
      overflow: hidden;
    `,routeMatchesToggleBtn:(e,r)=>{const o=[d`
        appearance: none;
        border: none;
        font-size: 12px;
        padding: 4px 8px;
        background: transparent;
        cursor: pointer;
        font-family: ${l.sans};
        font-weight: ${i.weight.medium};
      `];if(e){const e=d`
          background: ${t.darkGray[400]};
          color: ${t.gray[300]};
        `;o.push(e)}else{const e=d`
          color: ${t.gray[500]};
          background: ${t.darkGray[800]}${n[20]};
        `;o.push(e)}return r&&o.push(d`
          border-right: 1px solid ${D.colors.gray[500]};
        `),o},detailsHeaderInfo:d`
      flex: 1;
      justify-content: flex-end;
      display: flex;
      align-items: center;
      font-weight: ${i.weight.normal};
      color: ${t.gray[400]};
    `,matchRow:e=>{const i=[d`
        display: flex;
        border-bottom: 1px solid ${t.darkGray[400]};
        cursor: pointer;
        align-items: center;
        padding: ${r[1]} ${r[2]};
        gap: ${r[2]};
        font-size: ${s.xs};
        color: ${t.gray[300]};
      `];if(e){const e=d`
          background: ${t.darkGray[500]};
        `;i.push(e)}return i},matchIndicator:e=>{const i=[d`
        flex: 0 0 auto;
        width: ${r[3]};
        height: ${r[3]};
        background: ${t[e][900]};
        border: 1px solid ${t[e][500]};
        border-radius: ${o.radius.full};
        transition: all 0.25s ease-out;
        box-sizing: border-box;
      `];if("gray"===e){const e=d`
          background: ${t.gray[700]};
          border-color: ${t.gray[400]};
        `;i.push(e)}return i},matchID:d`
      flex: 1;
      line-height: ${a.xs};
    `,ageTicker:e=>{const i=[d`
        display: flex;
        gap: ${r[1]};
        font-size: ${s.xs};
        color: ${t.gray[400]};
        font-variant-numeric: tabular-nums;
        line-height: ${a.xs};
      `];if(e){const e=d`
          color: ${t.yellow[400]};
        `;i.push(e)}return i},secondContainer:d`
      flex: 1 1 500px;
      min-height: 40%;
      max-height: 100%;
      overflow: auto;
      border-right: 1px solid ${t.gray[700]};
      display: flex;
      flex-direction: column;
    `,thirdContainer:d`
      flex: 1 1 500px;
      overflow: auto;
      display: flex;
      flex-direction: column;
      height: 100%;
      border-right: 1px solid ${t.gray[700]};

      @media (max-width: 700px) {
        border-top: 2px solid ${t.gray[700]};
      }
    `,fourthContainer:d`
      flex: 1 1 500px;
      min-height: 40%;
      max-height: 100%;
      overflow: auto;
      display: flex;
      flex-direction: column;
    `,routesContainer:d`
      overflow-x: auto;
      overflow-y: visible;
    `,routesRowContainer:(e,i)=>{const n=[d`
        display: flex;
        border-bottom: 1px solid ${t.darkGray[400]};
        align-items: center;
        padding: ${r[1]} ${r[2]};
        gap: ${r[2]};
        font-size: ${s.xs};
        color: ${t.gray[300]};
        cursor: ${i?"pointer":"default"};
        line-height: ${a.xs};
      `];if(e){const e=d`
          background: ${t.darkGray[500]};
        `;n.push(e)}return n},routesRow:e=>{const i=[d`
        flex: 1 0 auto;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: ${s.xs};
        line-height: ${a.xs};
      `];if(!e){const e=d`
          color: ${t.gray[400]};
        `;i.push(e)}return i},routeParamInfo:d`
      color: ${t.gray[400]};
      font-size: ${s.xs};
      line-height: ${a.xs};
    `,nestedRouteRow:e=>d`
        margin-left: ${e?0:r[3.5]};
        border-left: ${e?"":`solid 1px ${t.gray[700]}`};
      `,code:d`
      font-size: ${s.xs};
      line-height: ${a.xs};
    `,matchesContainer:d`
      flex: 1 1 auto;
      overflow-y: auto;
    `,cachedMatchesContainer:d`
      flex: 1 1 auto;
      overflow-y: auto;
      max-height: 50%;
    `,maskedBadgeContainer:d`
      flex: 1;
      justify-content: flex-end;
      display: flex;
    `,matchDetails:d`
      display: flex;
      flex-direction: column;
      padding: ${D.size[2]};
      font-size: ${D.font.size.xs};
      color: ${D.colors.gray[300]};
      line-height: ${D.font.lineHeight.sm};
    `,matchStatus:(e,t)=>{const i=t&&"success"===e?"beforeLoad"===t?"purple":"blue":{pending:"yellow",success:"green",error:"red",notFound:"purple",redirected:"gray"}[e];return d`
        display: flex;
        justify-content: center;
        align-items: center;
        height: 40px;
        border-radius: ${D.border.radius.sm};
        font-weight: ${D.font.weight.normal};
        background-color: ${D.colors[i][900]}${D.alpha[90]};
        color: ${D.colors[i][300]};
        border: 1px solid ${D.colors[i][600]};
        margin-bottom: ${D.size[2]};
        transition: all 0.25s ease-out;
      `},matchDetailsInfo:d`
      display: flex;
      justify-content: flex-end;
      flex: 1;
    `,matchDetailsInfoLabel:d`
      display: flex;
    `,mainCloseBtn:d`
      background: ${t.darkGray[700]};
      padding: ${r[1]} ${r[2]} ${r[1]} ${r[1.5]};
      border-radius: ${o.radius.md};
      position: fixed;
      z-index: 99999;
      display: inline-flex;
      width: fit-content;
      cursor: pointer;
      appearance: none;
      border: 0;
      gap: 8px;
      align-items: center;
      border: 1px solid ${t.gray[500]};
      font-size: ${i.size.xs};
      cursor: pointer;
      transition: all 0.25s ease-out;

      &:hover {
        background: ${t.darkGray[500]};
      }
    `,mainCloseBtnPosition:e=>d`
        ${"top-left"===e?`top: ${r[2]}; left: ${r[2]};`:""}
        ${"top-right"===e?`top: ${r[2]}; right: ${r[2]};`:""}
        ${"bottom-left"===e?`bottom: ${r[2]}; left: ${r[2]};`:""}
        ${"bottom-right"===e?`bottom: ${r[2]}; right: ${r[2]};`:""}
      `,mainCloseBtnAnimation:e=>e?d`
        opacity: 0;
        pointer-events: none;
        visibility: hidden;
      `:d`
          opacity: 1;
          pointer-events: auto;
          visibility: visible;
        `,routerLogoCloseButton:d`
      font-weight: ${i.weight.semibold};
      font-size: ${i.size.xs};
      background: linear-gradient(to right, #98f30c, #00f4a3);
      background-clip: text;
      -webkit-background-clip: text;
      line-height: 1;
      -webkit-text-fill-color: transparent;
      white-space: nowrap;
    `,mainCloseBtnDivider:d`
      width: 1px;
      background: ${D.colors.gray[600]};
      height: 100%;
      border-radius: 999999px;
      color: transparent;
    `,mainCloseBtnIconContainer:d`
      position: relative;
      width: ${r[5]};
      height: ${r[5]};
      background: pink;
      border-radius: 999999px;
      overflow: hidden;
    `,mainCloseBtnIconOuter:d`
      width: ${r[5]};
      height: ${r[5]};
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      filter: blur(3px) saturate(1.8) contrast(2);
    `,mainCloseBtnIconInner:d`
      width: ${r[4]};
      height: ${r[4]};
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    `,panelCloseBtn:d`
      position: absolute;
      cursor: pointer;
      z-index: 100001;
      display: flex;
      align-items: center;
      justify-content: center;
      outline: none;
      background-color: ${t.darkGray[700]};
      &:hover {
        background-color: ${t.darkGray[500]};
      }

      top: 0;
      right: ${r[2]};
      transform: translate(0, -100%);
      border-right: ${t.darkGray[300]} 1px solid;
      border-left: ${t.darkGray[300]} 1px solid;
      border-top: ${t.darkGray[300]} 1px solid;
      border-bottom: none;
      border-radius: ${o.radius.sm} ${o.radius.sm} 0px 0px;
      padding: ${r[1]} ${r[1.5]} ${r[.5]} ${r[1.5]};

      &::after {
        content: ' ';
        position: absolute;
        top: 100%;
        left: -${r[2.5]};
        height: ${r[1.5]};
        width: calc(100% + ${r[5]});
      }
    `,panelCloseBtnIcon:d`
      color: ${t.gray[400]};
      width: ${r[2]};
      height: ${r[2]};
    `}})(e));return r}function I(e,t){const[n,o]=i();r((()=>{const i=(e=>{try{const t=localStorage.getItem(e);return"string"==typeof t?JSON.parse(t):void 0}catch{return}})(e);o(null==i?"function"==typeof t?t():t:i)}));return[n,t=>{o((i=>{let r=t;"function"==typeof t&&(r=t(i));try{localStorage.setItem(e,JSON.stringify(r))}catch{}return r}))}]}var A=l('<span><svg xmlns=http://www.w3.org/2000/svg width=12 height=12 fill=none viewBox="0 0 24 24"><path stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 18l6-6-6-6">'),T=l("<div>"),j=l("<button><span> "),L=l("<div><div><button> [<!> ... <!>]"),R=l("<button><span></span> 🔄 "),P=l("<span>:"),H=l("<span>");const N=({expanded:e,style:t={}})=>{const i=q();return r=A(),o=r.firstChild,n((t=>{var n=i().expander,l=$(i().expanderIcon(e));return n!==t.e&&d(r,t.e=n),l!==t.t&&c(o,"class",t.t=l),t}),{e:void 0,t:void 0}),r;var r,o};function J({value:e,defaultExpanded:t,pageSize:r=100,filterSubEntries:l,...c}){const[u,p]=i(Boolean(t)),g=o((()=>typeof e())),h=o((()=>{let i=[];const r=e=>{const i=!0===t?{[e.label]:!0}:null==t?void 0:t[e.label];return{...e,value:()=>e.value,defaultExpanded:i}};var n;return Array.isArray(e())?i=e().map(((e,t)=>r({label:t.toString(),value:e}))):null!==e()&&"object"==typeof e()&&(n=e(),Symbol.iterator in n)&&"function"==typeof e()[Symbol.iterator]?i=Array.from(e(),((e,t)=>r({label:t.toString(),value:e}))):"object"==typeof e()&&null!==e()&&(i=Object.entries(e()).map((([e,t])=>r({label:e,value:t})))),l?l(i):i})),v=o((()=>function(e,t){if(t<1)return[];let i=0;const r=[];for(;i<e.length;)r.push(e.slice(i,i+t)),i+=t;return r}(h(),r))),[x,m]=i([]),[b,y]=i(void 0),k=q(),C=()=>{y(e()())},S=t=>s(J,f({value:e,filterSubEntries:l},c,t));return F=T(),a(F,(w=o((()=>!!v().length)),()=>{return w()?[(i=j(),l=i.firstChild,f=l.firstChild,i.$$click=()=>p((e=>!e)),a(i,s(N,{get expanded(){return u()??!1}}),l),a(i,(()=>c.label),l),a(l,(()=>"iterable"===String(g).toLowerCase()?"(Iterable) ":""),f),a(l,(()=>h().length),f),a(l,(()=>h().length>1?"items":"item"),null),n((e=>{var t=k().expandButton,r=k().info;return t!==e.e&&d(i,e.e=t),r!==e.t&&d(l,e.t=r),e}),{e:void 0,t:void 0}),i),o((()=>{return o((()=>!!u()))()?o((()=>1===v().length))()?(t=T(),a(t,(()=>h().map(((e,t)=>S(e))))),n((()=>d(t,k().subEntries))),t):(e=T(),a(e,(()=>v().map(((e,t)=>{return l=L(),c=l.firstChild,f=c.firstChild,u=f.firstChild,p=u.nextSibling,(g=p.nextSibling.nextSibling).nextSibling,f.$$click=()=>m((e=>e.includes(t)?e.filter((e=>e!==t)):[...e,t])),a(f,s(N,{get expanded(){return x().includes(t)}}),u),a(f,t*r,p),a(f,t*r+r-1,g),a(c,(i=o((()=>!!x().includes(t))),()=>{return i()?(t=T(),a(t,(()=>e.map((e=>S(e))))),n((()=>d(t,k().subEntries))),t):null;var t}),null),n((e=>{var t=k().entry,i=$(k().labelButton,"labelButton");return t!==e.e&&d(c,e.e=t),i!==e.t&&d(f,e.t=i),e}),{e:void 0,t:void 0}),l;var i,l,c,f,u,p,g})))),n((()=>d(e,k().subEntries))),e):null;var e,t}))]:(t=o((()=>"function"===g())),()=>{return t()?s(J,{get label(){return e=R(),t=e.firstChild,e.$$click=C,a(t,(()=>c.label)),n((()=>d(e,k().refreshValueBtn))),e;var e,t},value:b,defaultExpanded:{}}):[(r=P(),o=r.firstChild,a(r,(()=>c.label),o),r)," ",(i=H(),a(i,(()=>(e=>{const t=Object.getOwnPropertyNames(Object(e)),i="bigint"==typeof e?`${e.toString()}n`:e;try{return JSON.stringify(i,t)}catch(r){return"unable to stringify"}})(e()))),n((()=>d(i,k().value))),i)];var i,r,o});var t,i,l,f})),n((()=>d(F,k().entry))),F;var w,F}const _=e=>{const{colors:t,font:i,size:r}=D,{fontFamily:n,lineHeight:o,size:l}=i,a=e?E.bind({target:e}):E;return{entry:a`
      font-family: ${n.mono};
      font-size: ${l.xs};
      line-height: ${o.sm};
      outline: none;
      word-break: break-word;
    `,labelButton:a`
      cursor: pointer;
      color: inherit;
      font: inherit;
      outline: inherit;
      background: transparent;
      border: none;
      padding: 0;
    `,expander:a`
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: ${r[3]};
      height: ${r[3]};
      padding-left: 3px;
      box-sizing: content-box;
    `,expanderIcon:e=>e?a`
          transform: rotate(90deg);
          transition: transform 0.1s ease;
        `:a`
        transform: rotate(0deg);
        transition: transform 0.1s ease;
      `,expandButton:a`
      display: flex;
      gap: ${r[1]};
      align-items: center;
      cursor: pointer;
      color: inherit;
      font: inherit;
      outline: inherit;
      background: transparent;
      border: none;
      padding: 0;
    `,value:a`
      color: ${t.purple[400]};
    `,subEntries:a`
      margin-left: ${r[2]};
      padding-left: ${r[2]};
      border-left: 2px solid ${t.darkGray[400]};
    `,info:a`
      color: ${t.gray[500]};
      font-size: ${l["2xs"]};
      padding-left: ${r[1]};
    `,refreshValueBtn:a`
      appearance: none;
      border: 0;
      cursor: pointer;
      background: transparent;
      color: inherit;
      padding: 0;
      font-family: ${n.mono};
      font-size: ${l.xs};
    `}};function q(){const e=t(y),[r]=i(_(e));return r}u(["click"]);var K=l("<div><div></div><div>/</div><div></div><div>/</div><div>");function V(e){const t=[e/1e3,e/6e4,e/36e5,e/864e5];let i=0;for(let r=1;r<t.length&&!(t[r]<1);r++)i=r;return new Intl.NumberFormat(navigator.language,{compactDisplay:"short",notation:"compact",maximumFractionDigits:0}).format(t[i])+["s","min","h","d"][i]}function Y({match:e,router:t}){const i=G();if(!e)return null;const r=t().looseRoutesById[e.routeId];if(!r.options.loader)return null;const o=Date.now()-e.updatedAt,l=r.options.staleTime??t().options.defaultStaleTime??0,s=r.options.gcTime??t().options.defaultGcTime??18e5;return c=K(),f=c.firstChild,u=f.nextSibling.nextSibling,p=u.nextSibling.nextSibling,a(f,(()=>V(o))),a(u,(()=>V(l))),a(p,(()=>V(s))),n((()=>d(c,$(i().ageTicker(o>l))))),c;var c,f,u,p}var W=l("<button><div>TANSTACK</div><div>TanStack Router v1"),Z=l("<div><div role=button><div></div><div><div><code> </code><code>"),Q=l("<div>"),X=l('<div><button><svg xmlns=http://www.w3.org/2000/svg width=10 height=6 fill=none viewBox="0 0 10 6"><path stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=1.667 d="M1 1l4 4 4-4"></path></svg></button><div><div></div><div><div></div></div></div><div><div><div><span>Pathname</span></div><div><code></code></div><div><div><button type=button>Routes</button><button type=button>Matches</button></div><div><div>age / staleTime / gcTime</div></div></div><div>'),ee=l("<div><span>masked"),te=l("<code>"),ie=l("<div role=button><div></div><code>"),re=l("<div><div><div>Cached Matches</div><div>age / staleTime / gcTime</div></div><div>"),ne=l("<div><div>Match Details</div><div><div><div><div></div></div><div><div>ID:</div><div><code></code></div></div><div><div>State:</div><div></div></div><div><div>Last Updated:</div><div></div></div></div></div><div>Explorer</div><div>"),oe=l("<div>Loader Data"),le=l("<div><div>Search Params</div><div>");function ae(e){const{className:t,...i}=e,r=G();return o=W(),l=o.firstChild,a=l.nextSibling,g(o,f(i,{get class(){return $(r().logo,t?t():"")}}),!1,!0),n((e=>{var t=r().tanstackLogo,i=r().routerLogo;return t!==e.e&&d(l,e.e=t),i!==e.t&&d(a,e.t=i),e}),{e:void 0,t:void 0}),o;var o,l,a}function se({routerState:e,router:t,route:i,isRoot:r,activeId:l,setActiveId:f}){const u=G(),p=o((()=>e().pendingMatches||e().matches)),g=o((()=>e().matches.find((e=>e.routeId===i.id)))),h=o((()=>{var e,t;try{if(null==(e=g())?void 0:e.params){const e=null==(t=g())?void 0:t.params,r=i.path||x(i.id);if(r.startsWith("$")){const t=r.slice(1);if(e[t])return`(${e[t]})`}}return""}catch(r){return""}}));return b=Z(),y=b.firstChild,k=y.firstChild,C=k.nextSibling,w=C.firstChild.firstChild,F=w.firstChild,z=w.nextSibling,y.$$click=()=>{g()&&f(l()===i.id?"":i.id)},a(w,(()=>r?v:i.path||x(i.id)),F),a(z,h),a(C,s(Y,{get match(){return g()},router:t}),null),a(b,(m=o((()=>{var e;return!!(null==(e=i.children)?void 0:e.length)})),()=>{return m()?(o=Q(),a(o,(()=>[...i.children].sort(((e,t)=>e.rank-t.rank)).map((i=>s(se,{routerState:e,router:t,route:i,activeId:l,setActiveId:f}))))),n((()=>d(o,u().nestedRouteRow(!!r)))),o):null;var o}),null),n((e=>{var t=`Open match details for ${i.id}`,r=$(u().routesRowContainer(i.id===l(),!!g())),n=$(u().matchIndicator(function(e,t){const i=e.find((e=>e.routeId===t.id));return i?S(i):"gray"}(p(),i))),o=$(u().routesRow(!!g())),a=u().code,s=u().routeParamInfo;return t!==e.e&&c(y,"aria-label",e.e=t),r!==e.t&&d(y,e.t=r),n!==e.a&&d(k,e.a=n),o!==e.o&&d(C,e.o=o),a!==e.i&&d(w,e.i=a),s!==e.n&&d(z,e.n=s),e}),{e:void 0,t:void 0,a:void 0,o:void 0,i:void 0,n:void 0}),b;var m,b,y,k,C,w,F,z}const de=function({...e}){const{isOpen:i=!0,setIsOpen:r,handleDragStart:l,router:u,routerState:x,shadowDOMTarget:m,...b}=e,{onCloseClick:y}=(()=>{const e=t(k);if(!e)throw new Error("useDevtoolsOnClose must be used within a TanStackRouterDevtools component");return e})(),C=G(),{className:w,style:F,...z}=b;p(u);const[U,M]=I("tanstackRouterDevtoolsShowMatches",!0),[O,B]=I("tanstackRouterDevtoolsActiveRouteId",""),E=o((()=>[...x().pendingMatches??[],...x().matches,...x().cachedMatches].find((e=>e.routeId===O()||e.id===O())))),D=o((()=>Object.keys(x().location.search).length)),A=o((()=>({...u(),state:x()}))),T=o((()=>Object.fromEntries(function(e,t=[e=>e]){return e.map(((e,t)=>[e,t])).sort((([e,i],[r,n])=>{for(const o of t){const t=o(e),i=o(r);if(void 0===t){if(void 0===i)continue;return 1}if(t!==i)return t>i?1:-1}return i-n})).map((([e])=>e))}(Object.keys(A()),["state","routesById","routesByPath","flatRoutes","options","manifest"].map((e=>t=>t!==e))).map((e=>[e,A()[e]])).filter((e=>"function"!=typeof e[1]&&!["__store","basepath","injectedHtml","subscribers","latestLoadPromise","navigateTimeout","resetNextScroll","tempLocationKey","latestLocation","routeTree","history"].includes(e[0])))))),j=o((()=>{var e;return null==(e=E())?void 0:e.loaderData})),L=o((()=>E())),R=o((()=>x().location.search));return(()=>{var e=X(),t=e.firstChild,i=t.firstChild,p=t.nextSibling,m=p.firstChild,b=m.nextSibling,k=b.firstChild,G=p.nextSibling,I=G.firstChild,A=I.firstChild;A.firstChild;var P,H,N,_,q,K,V,W=A.nextSibling,Z=W.firstChild,de=W.nextSibling,ce=de.firstChild,fe=ce.firstChild,ue=fe.nextSibling,pe=ce.nextSibling,ge=de.nextSibling;return g(e,f({get class(){return $(C().devtoolsPanel,"TanStackRouterDevtoolsPanel",w?w():"")},get style(){return F?F():""}},z),!1,!0),a(e,l?(P=Q(),h(P,"mousedown",l,!0),n((()=>d(P,C().dragHandle))),P):null,t),t.$$click=e=>{r&&r(!1),y(e)},a(m,s(ae,{"aria-hidden":!0,onClick:e=>{r&&r(!1),y(e)}})),a(k,s(J,{label:"Router",value:T,defaultExpanded:{state:{},context:{},options:{}},filterSubEntries:e=>e.filter((e=>"function"!=typeof e.value()))})),a(A,(H=o((()=>!!x().location.maskedLocation)),()=>{return H()?(e=ee(),t=e.firstChild,n((i=>{var r=C().maskedBadgeContainer,n=C().maskedBadge;return r!==i.e&&d(e,i.e=r),n!==i.t&&d(t,i.t=n),i}),{e:void 0,t:void 0}),e):null;var e,t}),null),a(Z,(()=>x().location.pathname)),a(W,(N=o((()=>!!x().location.maskedLocation)),()=>{return N()?(e=te(),a(e,(()=>{var e;return null==(e=x().location.maskedLocation)?void 0:e.pathname})),n((()=>d(e,C().maskedLocation))),e):null;var e}),null),fe.$$click=()=>{M(!1)},ue.$$click=()=>{M(!0)},a(ge,(_=o((()=>!U())),()=>{return _()?s(se,{routerState:x,router:u,get route(){return u().routeTree},isRoot:!0,activeId:O,setActiveId:B}):(e=Q(),a(e,(()=>{var e,t;return null==(t=(null==(e=x().pendingMatches)?void 0:e.length)?x().pendingMatches:x().matches)?void 0:t.map(((e,t)=>{return i=ie(),r=i.firstChild,o=r.nextSibling,i.$$click=()=>B(O()===e.id?"":e.id),a(o,(()=>`${e.routeId===v?v:e.pathname}`)),a(i,s(Y,{match:e,router:u}),null),n((t=>{var n=`Open match details for ${e.id}`,l=$(C().matchRow(e===E())),a=$(C().matchIndicator(S(e))),s=C().matchID;return n!==t.e&&c(i,"aria-label",t.e=n),l!==t.t&&d(i,t.t=l),a!==t.a&&d(r,t.a=a),s!==t.o&&d(o,t.o=s),t}),{e:void 0,t:void 0,a:void 0,o:void 0}),i;var i,r,o}))})),e);var e})),a(G,(q=o((()=>!!x().cachedMatches.length)),()=>{return q()?(e=re(),t=e.firstChild,i=t.firstChild.nextSibling,r=t.nextSibling,a(r,(()=>x().cachedMatches.map((e=>{return t=ie(),i=t.firstChild,r=i.nextSibling,t.$$click=()=>B(O()===e.id?"":e.id),a(r,(()=>`${e.id}`)),a(t,s(Y,{match:e,router:u}),null),n((n=>{var o=`Open match details for ${e.id}`,l=$(C().matchRow(e===E())),a=$(C().matchIndicator(S(e))),s=C().matchID;return o!==n.e&&c(t,"aria-label",n.e=o),l!==n.t&&d(t,n.t=l),a!==n.a&&d(i,n.a=a),s!==n.o&&d(r,n.o=s),n}),{e:void 0,t:void 0,a:void 0,o:void 0}),t;var t,i,r})))),n((r=>{var n=C().cachedMatchesContainer,o=C().detailsHeader,l=C().detailsHeaderInfo;return n!==r.e&&d(e,r.e=n),o!==r.t&&d(t,r.t=o),l!==r.a&&d(i,r.a=l),r}),{e:void 0,t:void 0,a:void 0}),e):null;var e,t,i,r}),null),a(e,(K=o((()=>{var e;return!(!E()||!(null==(e=E())?void 0:e.status))})),()=>{return K()?(l=ne(),c=l.firstChild,f=c.nextSibling,u=f.firstChild,p=u.firstChild,g=p.firstChild,h=p.nextSibling,v=h.firstChild.nextSibling,m=v.firstChild,b=h.nextSibling,$=b.firstChild.nextSibling,y=b.nextSibling,k=y.firstChild.nextSibling,S=f.nextSibling,w=S.nextSibling,a(g,(e=o((()=>{var e,t;return!("success"!==(null==(e=E())?void 0:e.status)||!(null==(t=E())?void 0:t.isFetching))})),()=>{var t;return e()?"fetching":null==(t=E())?void 0:t.status})),a(m,(()=>{var e;return null==(e=E())?void 0:e.id})),a($,(t=o((()=>{var e;return!!(null==(e=x().pendingMatches)?void 0:e.find((e=>{var t;return e.id===(null==(t=E())?void 0:t.id)})))})),()=>t()?"Pending":x().matches.find((e=>{var t;return e.id===(null==(t=E())?void 0:t.id)}))?"Active":"Cached")),a(k,(i=o((()=>{var e;return!!(null==(e=E())?void 0:e.updatedAt)})),()=>{var e;return i()?new Date(null==(e=E())?void 0:e.updatedAt).toLocaleTimeString():"N/A"})),a(l,(r=o((()=>!!j())),()=>{return r()?[(t=oe(),n((()=>d(t,C().detailsHeader))),t),(e=Q(),a(e,s(J,{label:"loaderData",value:j,defaultExpanded:{}})),n((()=>d(e,C().detailsContent))),e)]:null;var e,t}),S),a(w,s(J,{label:"Match",value:L,defaultExpanded:{}})),n((e=>{var t,i,r=C().thirdContainer,n=C().detailsHeader,o=C().matchDetails,a=C().matchStatus(null==(t=E())?void 0:t.status,null==(i=E())?void 0:i.isFetching),s=C().matchDetailsInfoLabel,f=C().matchDetailsInfo,g=C().matchDetailsInfoLabel,x=C().matchDetailsInfo,m=C().matchDetailsInfoLabel,F=C().matchDetailsInfo,z=C().detailsHeader,U=C().detailsContent;return r!==e.e&&d(l,e.e=r),n!==e.t&&d(c,e.t=n),o!==e.a&&d(u,e.a=o),a!==e.o&&d(p,e.o=a),s!==e.i&&d(h,e.i=s),f!==e.n&&d(v,e.n=f),g!==e.s&&d(b,e.s=g),x!==e.h&&d($,e.h=x),m!==e.r&&d(y,e.r=m),F!==e.d&&d(k,e.d=F),z!==e.l&&d(S,e.l=z),U!==e.u&&d(w,e.u=U),e}),{e:void 0,t:void 0,a:void 0,o:void 0,i:void 0,n:void 0,s:void 0,h:void 0,r:void 0,d:void 0,l:void 0,u:void 0}),l):null;var e,t,i,r,l,c,f,u,p,g,h,v,m,b,$,y,k,S,w}),null),a(e,(V=o((()=>!!D())),()=>{return V()?(e=le(),t=e.firstChild,i=t.nextSibling,a(i,s(J,{value:R,get defaultExpanded(){return Object.keys(x().location.search).reduce(((e,t)=>(e[t]={},e)),{})}})),n((r=>{var n=C().fourthContainer,o=C().detailsHeader,l=C().detailsContent;return n!==r.e&&d(e,r.e=n),o!==r.t&&d(t,r.t=o),l!==r.a&&d(i,r.a=l),r}),{e:void 0,t:void 0,a:void 0}),e):null;var e,t,i}),null),n((e=>{var r=C().panelCloseBtn,n=C().panelCloseBtnIcon,o=C().firstContainer,l=C().row,a=C().routerExplorerContainer,s=C().routerExplorer,f=C().secondContainer,u=C().matchesContainer,g=C().detailsHeader,h=C().detailsContent,v=C().detailsHeader,x=C().routeMatchesToggle,y=!U(),S=$(C().routeMatchesToggleBtn(!U(),!0)),w=U(),F=$(C().routeMatchesToggleBtn(!!U(),!1)),z=C().detailsHeaderInfo,M=$(C().routesContainer);return r!==e.e&&d(t,e.e=r),n!==e.t&&c(i,"class",e.t=n),o!==e.a&&d(p,e.a=o),l!==e.o&&d(m,e.o=l),a!==e.i&&d(b,e.i=a),s!==e.n&&d(k,e.n=s),f!==e.s&&d(G,e.s=f),u!==e.h&&d(I,e.h=u),g!==e.r&&d(A,e.r=g),h!==e.d&&d(W,e.d=h),v!==e.l&&d(de,e.l=v),x!==e.u&&d(ce,e.u=x),y!==e.c&&(fe.disabled=e.c=y),S!==e.w&&d(fe,e.w=S),w!==e.m&&(ue.disabled=e.m=w),F!==e.f&&d(ue,e.f=F),z!==e.y&&d(pe,e.y=z),M!==e.g&&d(ge,e.g=M),e}),{e:void 0,t:void 0,a:void 0,o:void 0,i:void 0,n:void 0,s:void 0,h:void 0,r:void 0,d:void 0,l:void 0,u:void 0,c:void 0,w:void 0,m:void 0,f:void 0,y:void 0,g:void 0}),e})()};u(["click","mousedown"]);var ce=l('<svg xmlns=http://www.w3.org/2000/svg enable-background="new 0 0 634 633"viewBox="0 0 634 633"><g transform=translate(1)><linearGradient x1=-641.486 x2=-641.486 y1=856.648 y2=855.931 gradientTransform="matrix(633 0 0 -633 406377 542258)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#6bdaff></stop><stop offset=0.319 stop-color=#f9ffb5></stop><stop offset=0.706 stop-color=#ffa770></stop><stop offset=1 stop-color=#ff7373></stop></linearGradient><circle cx=316.5 cy=316.5 r=316.5 fill-rule=evenodd clip-rule=evenodd></circle><defs><filter width=454 height=396.9 x=-137.5 y=412 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=454 height=396.9 x=-137.5 y=412 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><ellipse cx=89.5 cy=610.5 fill=#015064 fill-rule=evenodd stroke=#00CFE2 stroke-width=25 clip-rule=evenodd rx=214.5 ry=186></ellipse><defs><filter width=454 height=396.9 x=316.5 y=412 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=454 height=396.9 x=316.5 y=412 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><ellipse cx=543.5 cy=610.5 fill=#015064 fill-rule=evenodd stroke=#00CFE2 stroke-width=25 clip-rule=evenodd rx=214.5 ry=186></ellipse><defs><filter width=454 height=396.9 x=-137.5 y=450 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=454 height=396.9 x=-137.5 y=450 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><ellipse cx=89.5 cy=648.5 fill=#015064 fill-rule=evenodd stroke=#00A8B8 stroke-width=25 clip-rule=evenodd rx=214.5 ry=186></ellipse><defs><filter width=454 height=396.9 x=316.5 y=450 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=454 height=396.9 x=316.5 y=450 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><ellipse cx=543.5 cy=648.5 fill=#015064 fill-rule=evenodd stroke=#00A8B8 stroke-width=25 clip-rule=evenodd rx=214.5 ry=186></ellipse><defs><filter width=454 height=396.9 x=-137.5 y=486 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=454 height=396.9 x=-137.5 y=486 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><ellipse cx=89.5 cy=684.5 fill=#015064 fill-rule=evenodd stroke=#007782 stroke-width=25 clip-rule=evenodd rx=214.5 ry=186></ellipse><defs><filter width=454 height=396.9 x=316.5 y=486 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=454 height=396.9 x=316.5 y=486 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><ellipse cx=543.5 cy=684.5 fill=#015064 fill-rule=evenodd stroke=#007782 stroke-width=25 clip-rule=evenodd rx=214.5 ry=186></ellipse><defs><filter width=176.9 height=129.3 x=272.2 y=308 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=176.9 height=129.3 x=272.2 y=308 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><g><path fill=none stroke=#000 stroke-linecap=round stroke-linejoin=bevel stroke-width=11 d="M436 403.2l-5 28.6m-140-90.3l-10.9 62m52.8-19.4l-4.3 27.1"></path><linearGradient x1=-645.656 x2=-646.499 y1=854.878 y2=854.788 gradientTransform="matrix(-184.159 -32.4722 11.4608 -64.9973 -128419.844 34938.836)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ee2700></stop><stop offset=1 stop-color=#ff008e></stop></linearGradient><path fill-rule=evenodd d="M344.1 363l97.7 17.2c5.8 2.1 8.2 6.2 7.1 12.1-1 5.9-4.7 9.2-11 9.9l-106-18.7-57.5-59.2c-3.2-4.8-2.9-9.1.8-12.8 3.7-3.7 8.3-4.4 13.7-2.1l55.2 53.6z"clip-rule=evenodd></path><path fill=#D8D8D8 fill-rule=evenodd stroke=#FFF stroke-linecap=round stroke-linejoin=bevel stroke-width=7 d="M428.3 384.5l.9-6.5m-33.9 1.5l.9-6.5m-34 .5l.9-6.1m-38.9-16.1l4.2-3.9m-25.2-16.1l4.2-3.9"clip-rule=evenodd></path></g><defs><filter width=280.6 height=317.4 x=73.2 y=113.9 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=280.6 height=317.4 x=73.2 y=113.9 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><g><linearGradient x1=-646.8 x2=-646.8 y1=854.844 y2=853.844 gradientTransform="matrix(-100.1751 48.8587 -97.9753 -200.879 19124.773 203538.61)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#a17500></stop><stop offset=1 stop-color=#5d2100></stop></linearGradient><path fill-rule=evenodd d="M192.3 203c8.1 37.3 14 73.6 17.8 109.1 3.8 35.4 2.8 75.2-2.9 119.2l61.2-16.7c-15.6-59-25.2-97.9-28.6-116.6-3.4-18.7-10.8-51.8-22.2-99.6l-25.3 4.6"clip-rule=evenodd></path><linearGradient x1=-635.467 x2=-635.467 y1=852.115 y2=851.115 gradientTransform="matrix(92.6873 4.8575 2.0257 -38.6535 57323.695 36176.047)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#2f8a00></stop><stop offset=1 stop-color=#90ff57></stop></linearGradient><path fill-rule=evenodd stroke=#2F8A00 stroke-width=13 d="M195 183.9s-12.6-22.1-36.5-29.9c-15.9-5.2-34.4-1.5-55.5 11.1 15.9 14.3 29.5 22.6 40.7 24.9 16.8 3.6 51.3-6.1 51.3-6.1z"clip-rule=evenodd></path><linearGradient x1=-636.573 x2=-636.573 y1=855.444 y2=854.444 gradientTransform="matrix(109.9945 5.7646 6.3597 -121.3507 64719.133 107659.336)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#2f8a00></stop><stop offset=1 stop-color=#90ff57></stop></linearGradient><path fill-rule=evenodd stroke=#2F8A00 stroke-width=13 d="M194.9 184.5s-47.5-8.5-83.2 15.7c-23.8 16.2-34.3 49.3-31.6 99.3 30.3-27.8 52.1-48.5 65.2-61.9 19.8-20 49.6-53.1 49.6-53.1z"clip-rule=evenodd></path><linearGradient x1=-632.145 x2=-632.145 y1=854.174 y2=853.174 gradientTransform="matrix(62.9558 3.2994 3.5021 -66.8246 37035.367 59284.227)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#2f8a00></stop><stop offset=1 stop-color=#90ff57></stop></linearGradient><path fill-rule=evenodd stroke=#2F8A00 stroke-width=13 d="M195 183.9c-.8-21.9 6-38 20.6-48.2 14.6-10.2 29.8-15.3 45.5-15.3-6.1 21.4-14.5 35.8-25.2 43.4-10.7 7.5-24.4 14.2-40.9 20.1z"clip-rule=evenodd></path><linearGradient x1=-638.224 x2=-638.224 y1=853.801 y2=852.801 gradientTransform="matrix(152.4666 7.9904 3.0934 -59.0251 94939.86 55646.855)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#2f8a00></stop><stop offset=1 stop-color=#90ff57></stop></linearGradient><path fill-rule=evenodd stroke=#2F8A00 stroke-width=13 d="M194.9 184.5c31.9-30 64.1-39.7 96.7-29 32.6 10.7 50.8 30.4 54.6 59.1-35.2-5.5-60.4-9.6-75.8-12.1-15.3-2.6-40.5-8.6-75.5-18z"clip-rule=evenodd></path><linearGradient x1=-637.723 x2=-637.723 y1=855.103 y2=854.103 gradientTransform="matrix(136.467 7.1519 5.2165 -99.5377 82830.875 89859.578)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#2f8a00></stop><stop offset=1 stop-color=#90ff57></stop></linearGradient><path fill-rule=evenodd stroke=#2F8A00 stroke-width=13 d="M194.9 184.5c35.8-7.6 65.6-.2 89.2 22 23.6 22.2 37.7 49 42.3 80.3-39.8-9.7-68.3-23.8-85.5-42.4-17.2-18.5-32.5-38.5-46-59.9z"clip-rule=evenodd></path><linearGradient x1=-631.79 x2=-631.79 y1=855.872 y2=854.872 gradientTransform="matrix(60.8683 3.19 8.7771 -167.4773 31110.818 145537.61)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#2f8a00></stop><stop offset=1 stop-color=#90ff57></stop></linearGradient><path fill-rule=evenodd stroke=#2F8A00 stroke-width=13 d="M194.9 184.5c-33.6 13.8-53.6 35.7-60.1 65.6-6.5 29.9-3.6 63.1 8.7 99.6 27.4-40.3 43.2-69.6 47.4-88 4.2-18.3 5.5-44.1 4-77.2z"clip-rule=evenodd></path><path fill=none stroke=#2F8A00 stroke-linecap=round stroke-width=8 d="M196.5 182.3c-14.8 21.6-25.1 41.4-30.8 59.4-5.7 18-9.4 33-11.1 45.1"></path><path fill=none stroke=#2F8A00 stroke-linecap=round stroke-width=8 d="M194.8 185.7c-24.4 1.7-43.8 9-58.1 21.8-14.3 12.8-24.7 25.4-31.3 37.8m99.1-68.9c29.7-6.7 52-8.4 67-5 15 3.4 26.9 8.7 35.8 15.9m-110.8-5.9c20.3 9.9 38.2 20.5 53.9 31.9 15.7 11.4 27.4 22.1 35.1 32"></path></g><defs><filter width=532 height=633 x=50.5 y=399 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=532 height=633 x=50.5 y=399 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><linearGradient x1=-641.104 x2=-641.278 y1=856.577 y2=856.183 gradientTransform="matrix(532 0 0 -633 341484.5 542657)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#fff400></stop><stop offset=1 stop-color=#3c8700></stop></linearGradient><ellipse cx=316.5 cy=715.5 fill-rule=evenodd clip-rule=evenodd rx=266 ry=316.5></ellipse><defs><filter width=288 height=283 x=391 y=-24 filterUnits=userSpaceOnUse><feColorMatrix values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix></filter></defs><mask width=288 height=283 x=391 y=-24 maskUnits=userSpaceOnUse><g><circle cx=316.5 cy=316.5 r=316.5 fill=#FFF fill-rule=evenodd clip-rule=evenodd></circle></g></mask><g><g transform="translate(397 -24)"><linearGradient x1=-1036.672 x2=-1036.672 y1=880.018 y2=879.018 gradientTransform="matrix(227 0 0 -227 235493 199764)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffdf00></stop><stop offset=1 stop-color=#ff9d00></stop></linearGradient><circle cx=168.5 cy=113.5 r=113.5 fill-rule=evenodd clip-rule=evenodd></circle><linearGradient x1=-1017.329 x2=-1018.602 y1=658.003 y2=657.998 gradientTransform="matrix(30 0 0 -1 30558 771)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffa400></stop><stop offset=1 stop-color=#ff5e00></stop></linearGradient><path fill=none stroke-linecap=round stroke-linejoin=bevel stroke-width=12 d="M30 113H0"></path><linearGradient x1=-1014.501 x2=-1015.774 y1=839.985 y2=839.935 gradientTransform="matrix(26.5 0 0 -5.5 26925 4696.5)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffa400></stop><stop offset=1 stop-color=#ff5e00></stop></linearGradient><path fill=none stroke-linecap=round stroke-linejoin=bevel stroke-width=12 d="M33.5 79.5L7 74"></path><linearGradient x1=-1016.59 x2=-1017.862 y1=852.671 y2=852.595 gradientTransform="matrix(29 0 0 -8 29523 6971)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffa400></stop><stop offset=1 stop-color=#ff5e00></stop></linearGradient><path fill=none stroke-linecap=round stroke-linejoin=bevel stroke-width=12 d="M34 146l-29 8"></path><linearGradient x1=-1011.984 x2=-1013.257 y1=863.523 y2=863.229 gradientTransform="matrix(24 0 0 -13 24339 11407)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffa400></stop><stop offset=1 stop-color=#ff5e00></stop></linearGradient><path fill=none stroke-linecap=round stroke-linejoin=bevel stroke-width=12 d="M45 177l-24 13"></path><linearGradient x1=-1006.673 x2=-1007.946 y1=869.279 y2=868.376 gradientTransform="matrix(20 0 0 -19 20205 16720)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffa400></stop><stop offset=1 stop-color=#ff5e00></stop></linearGradient><path fill=none stroke-linecap=round stroke-linejoin=bevel stroke-width=12 d="M67 204l-20 19"></path><linearGradient x1=-992.85 x2=-993.317 y1=871.258 y2=870.258 gradientTransform="matrix(13.8339 0 0 -22.8467 13825.796 20131.938)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffa400></stop><stop offset=1 stop-color=#ff5e00></stop></linearGradient><path fill=none stroke-linecap=round stroke-linejoin=bevel stroke-width=12 d="M94.4 227l-13.8 22.8"></path><linearGradient x1=-953.835 x2=-953.965 y1=871.9 y2=870.9 gradientTransform="matrix(7.5 0 0 -24.5 7278 21605)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffa400></stop><stop offset=1 stop-color=#ff5e00></stop></linearGradient><path fill=none stroke-linecap=round stroke-linejoin=bevel stroke-width=12 d="M127.5 243.5L120 268"></path><linearGradient x1=244.504 x2=244.496 y1=871.898 y2=870.898 gradientTransform="matrix(.5 0 0 -24.5 45.5 21614)"gradientUnits=userSpaceOnUse><stop offset=0 stop-color=#ffa400></stop><stop offset=1 stop-color=#ff5e00></stop></linearGradient><path fill=none stroke-linecap=round stroke-linejoin=bevel stroke-width=12 d="M167.5 252.5l.5 24.5">');function fe(){const e=m();return t=ce(),i=t.firstChild.firstChild,r=i.nextSibling,n=r.nextSibling,o=n.firstChild,l=n.nextSibling,a=l.firstChild,s=l.nextSibling,d=s.nextSibling,f=d.firstChild,u=d.nextSibling,p=u.firstChild,g=u.nextSibling,h=g.nextSibling,v=h.firstChild,x=h.nextSibling,b=x.firstChild,$=x.nextSibling,y=$.nextSibling,k=y.firstChild,C=y.nextSibling,S=C.firstChild,w=C.nextSibling,F=w.nextSibling,z=F.firstChild,U=F.nextSibling,M=U.firstChild,O=U.nextSibling,B=O.nextSibling,E=B.firstChild,D=B.nextSibling,G=D.firstChild,I=D.nextSibling,A=I.nextSibling,T=A.firstChild,j=A.nextSibling,L=j.firstChild,R=j.nextSibling,P=R.firstChild.nextSibling,H=P.nextSibling,N=R.nextSibling,J=N.firstChild,_=N.nextSibling,q=_.firstChild,K=_.nextSibling,V=K.firstChild,Y=V.nextSibling,W=Y.nextSibling,Z=W.nextSibling,Q=Z.nextSibling,X=Q.nextSibling,ee=X.nextSibling,te=ee.nextSibling,ie=te.nextSibling,re=ie.nextSibling,ne=re.nextSibling,oe=ne.nextSibling,le=oe.nextSibling,ae=le.nextSibling,se=K.nextSibling,de=se.firstChild,fe=se.nextSibling,ue=fe.firstChild,pe=fe.nextSibling,ge=pe.nextSibling,he=ge.nextSibling,ve=he.firstChild,xe=he.nextSibling,me=xe.firstChild,be=xe.nextSibling,$e=be.firstChild.firstChild,ye=$e.nextSibling,ke=ye.nextSibling,Ce=ke.nextSibling,Se=Ce.nextSibling,we=Se.nextSibling,Fe=we.nextSibling,ze=Fe.nextSibling,Ue=ze.nextSibling,Me=Ue.nextSibling,Oe=Me.nextSibling,Be=Oe.nextSibling,Ee=Be.nextSibling,De=Ee.nextSibling,Ge=De.nextSibling,Ie=Ge.nextSibling,Ae=Ie.nextSibling,Te=Ae.nextSibling,c(i,"id",`a-${e}`),c(r,"fill",`url(#a-${e})`),c(o,"id",`b-${e}`),c(l,"id",`c-${e}`),c(a,"filter",`url(#b-${e})`),c(s,"mask",`url(#c-${e})`),c(f,"id",`d-${e}`),c(u,"id",`e-${e}`),c(p,"filter",`url(#d-${e})`),c(g,"mask",`url(#e-${e})`),c(v,"id",`f-${e}`),c(x,"id",`g-${e}`),c(b,"filter",`url(#f-${e})`),c($,"mask",`url(#g-${e})`),c(k,"id",`h-${e}`),c(C,"id",`i-${e}`),c(S,"filter",`url(#h-${e})`),c(w,"mask",`url(#i-${e})`),c(z,"id",`j-${e}`),c(U,"id",`k-${e}`),c(M,"filter",`url(#j-${e})`),c(O,"mask",`url(#k-${e})`),c(E,"id",`l-${e}`),c(D,"id",`m-${e}`),c(G,"filter",`url(#l-${e})`),c(I,"mask",`url(#m-${e})`),c(T,"id",`n-${e}`),c(j,"id",`o-${e}`),c(L,"filter",`url(#n-${e})`),c(R,"mask",`url(#o-${e})`),c(P,"id",`p-${e}`),c(H,"fill",`url(#p-${e})`),c(J,"id",`q-${e}`),c(_,"id",`r-${e}`),c(q,"filter",`url(#q-${e})`),c(K,"mask",`url(#r-${e})`),c(V,"id",`s-${e}`),c(Y,"fill",`url(#s-${e})`),c(W,"id",`t-${e}`),c(Z,"fill",`url(#t-${e})`),c(Q,"id",`u-${e}`),c(X,"fill",`url(#u-${e})`),c(ee,"id",`v-${e}`),c(te,"fill",`url(#v-${e})`),c(ie,"id",`w-${e}`),c(re,"fill",`url(#w-${e})`),c(ne,"id",`x-${e}`),c(oe,"fill",`url(#x-${e})`),c(le,"id",`y-${e}`),c(ae,"fill",`url(#y-${e})`),c(de,"id",`z-${e}`),c(fe,"id",`A-${e}`),c(ue,"filter",`url(#z-${e})`),c(pe,"id",`B-${e}`),c(ge,"fill",`url(#B-${e})`),c(ge,"mask",`url(#A-${e})`),c(ve,"id",`C-${e}`),c(xe,"id",`D-${e}`),c(me,"filter",`url(#C-${e})`),c(be,"mask",`url(#D-${e})`),c($e,"id",`E-${e}`),c(ye,"fill",`url(#E-${e})`),c(ke,"id",`F-${e}`),c(Ce,"stroke",`url(#F-${e})`),c(Se,"id",`G-${e}`),c(we,"stroke",`url(#G-${e})`),c(Fe,"id",`H-${e}`),c(ze,"stroke",`url(#H-${e})`),c(Ue,"id",`I-${e}`),c(Me,"stroke",`url(#I-${e})`),c(Oe,"id",`J-${e}`),c(Be,"stroke",`url(#J-${e})`),c(Ee,"id",`K-${e}`),c(De,"stroke",`url(#K-${e})`),c(Ge,"id",`L-${e}`),c(Ie,"stroke",`url(#L-${e})`),c(Ae,"id",`M-${e}`),c(Te,"stroke",`url(#M-${e})`),t;var t,i,r,n,o,l,a,s,d,f,u,p,g,h,v,x,b,$,y,k,C,S,w,F,z,U,M,O,B,E,D,G,I,A,T,j,L,R,P,H,N,J,_,q,K,V,Y,W,Z,Q,X,ee,te,ie,re,ne,oe,le,ae,se,de,fe,ue,pe,ge,he,ve,xe,me,be,$e,ye,ke,Ce,Se,we,Fe,ze,Ue,Me,Oe,Be,Ee,De,Ge,Ie,Ae,Te}var ue=l("<button type=button><div><div></div><div></div></div><div>-</div><div>TanStack Router");function pe({initialIsOpen:e,panelProps:t={},closeButtonProps:l={},toggleButtonProps:c={},position:u="bottom-left",containerElement:p="footer",router:h,routerState:v,shadowDOMTarget:x}){const[m,y]=i();let S;const[w,F]=I("tanstackRouterDevtoolsOpen",e),[z,U]=I("tanstackRouterDevtoolsHeight",null),[M,O]=i(!1),[B,E]=i(!1),D=function(){const[e,t]=i(!1);return(C?r:n)((()=>{t(!0)})),e}(),A=G();w(),r((()=>{O(w()??!1)})),r((()=>{var e,t;if(M()){const i=null==(t=null==(e=m())?void 0:e.parentElement)?void 0:t.style.paddingBottom,r=()=>{var e;const t=S.getBoundingClientRect().height;(null==(e=m())?void 0:e.parentElement)&&y((e=>((null==e?void 0:e.parentElement)&&(e.parentElement.style.paddingBottom=`${t}px`),e)))};if(r(),"undefined"!=typeof window)return window.addEventListener("resize",r),()=>{var e;window.removeEventListener("resize",r),(null==(e=m())?void 0:e.parentElement)&&"string"==typeof i&&y((e=>(e.parentElement.style.paddingBottom=i,e)))}}})),r((()=>{if(m()){const e=m(),t=getComputedStyle(e).fontSize;null==e||e.style.setProperty("--tsrd-font-size",t)}}));const{style:T={},...j}=t,{style:L={},onClick:R,...P}=l,{onClick:H,class:N,...J}=c;if(!D())return null;const _=o((()=>z()??500)),q=o((()=>$(A().devtoolsPanelContainer,A().devtoolsPanelContainerVisibility(!!w()),A().devtoolsPanelContainerResizing(B),A().devtoolsPanelContainerAnimation(M(),_()+16)))),K=o((()=>({height:`${_()}px`,...T||{}}))),V=o((()=>$(A().mainCloseBtn,A().mainCloseBtnPosition(u),A().mainCloseBtnAnimation(!!w()),N)));return s(b,{component:p,ref:y,class:"TanStackRouterDevtools",get children(){return[s(k.Provider,{value:{onCloseClick:R??(()=>{})},get children(){return s(de,f({ref(e){"function"==typeof S?S(e):S=e}},j,{router:h,routerState:v,className:q,style:K,get isOpen(){return M()},setIsOpen:F,handleDragStart:e=>((e,t)=>{if(0!==t.button)return;E(!0);const i=(null==e?void 0:e.getBoundingClientRect().height)??0,r=t.pageY,n=e=>{const t=r-e.pageY,n=i+t;U(n),F(!(n<70))},o=()=>{E(!1),document.removeEventListener("mousemove",n),document.removeEventListener("mouseUp",o)};document.addEventListener("mousemove",n),document.addEventListener("mouseup",o)})(S,e),shadowDOMTarget:x}))}}),(e=ue(),t=e.firstChild,i=t.firstChild,r=i.nextSibling,o=t.nextSibling,l=o.nextSibling,g(e,f(J,{"aria-label":"Open TanStack Router Devtools",onClick:e=>{F(!0),H&&H(e)},get class(){return V()}}),!1,!0),a(i,s(fe,{})),a(r,s(fe,{})),n((e=>{var n=A().mainCloseBtnIconContainer,a=A().mainCloseBtnIconOuter,s=A().mainCloseBtnIconInner,c=A().mainCloseBtnDivider,f=A().routerLogoCloseButton;return n!==e.e&&d(t,e.e=n),a!==e.t&&d(i,e.t=a),s!==e.a&&d(r,e.a=s),c!==e.o&&d(o,e.o=c),f!==e.i&&d(l,e.i=f),e}),{e:void 0,t:void 0,a:void 0,o:void 0,i:void 0}),e)];var e,t,i,r,o,l}})}export{pe as FloatingTanStackRouterDevtools,pe as default};
